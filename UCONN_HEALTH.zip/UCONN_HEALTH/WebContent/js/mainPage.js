var medical_record = medical_record;
document.getElementById("mainPage").innerHTML = innerHTML = '<object type="text/html" data="doctor.html" style="height: 100%; width: 100%" ></object>';
;