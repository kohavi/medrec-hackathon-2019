var medical_record = {
	"patient_id" : "1",
	"prescription" : [ {
		"name" : "Metformin",
		"route" : "Orally",
		"Dosage" : "500mg",
		"frequency" : "BID",
		"days_supply" : "90",
		"script_date" : "02/03/2019",
		"trans_date" : "02/10/2019",
		"prescriber" : "Andreson",
		"comment" : ""
	}, {
		"name" : "Amlodipine",
		"route" : "Orally",
		"Dosage" : "350mg",
		"frequency" : "BID",
		"days_supply" : "90",
		"script_date" : "04/03/2019",
		"trans_date" : "04/10/2019",
		"prescriber" : "Andrew",
		"comment" : ""
	}, {
		"name" : "Paracetamol",
		"route" : "Orally",
		"Dosage" : "500mg",
		"frequency" : "BID",
		"days_supply" : "90",
		"script_date" : "05/30/2019",
		"trans_date" : "06/10/2019",
		"prescriber" : "James",
		"comment" : ""
	}, {
		"name" : "Azithromycin ",
		"route" : "Orally",
		"Dosage" : "100mg",
		"frequency" : "BID",
		"days_supply" : "90",
		"script_date" : "06/06/2019",
		"trans_date" : "07/10/2019",
		"prescriber" : "Andreson",
		"comment" : ""
	}, {
		"name" : "Lipitor ",
		"route" : "Orally",
		"Dosage" : "500mg",
		"frequency" : "Daily",
		"days_supply" : "60",
		"script_date" : "04/03/2019",
		"trans_date" : "04/20/2019",
		"prescriber" : "James",
		"comment" : ""
	}, {
		"name" : "Amoxicillin",
		"route" : "Orally",
		"Dosage" : "500mg",
		"frequency" : "daily",
		"days_supply" : "10",
		"script_date" : "09/03/2019",
		"trans_date" : "09/10/2019",
		"prescriber" : "Andrew",
		"comment" : ""
	} ]
};
