/*var medical_record = {
	"patient_id" : "1",
	"prescription" : [ {
		"name" : "med1",
		"Dosage" : "500mg",
		"frequency" : "2",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "50mg",
		"frequency" : "1",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "350mg",
		"frequency" : "1",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "500mg",
		"frequency" : "2",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "50mg",
		"frequency" : "1",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "350mg",
		"frequency" : "1",
		"comment" : ""
	} ]
};
 */
(function abc($) {
	"use strict";
	$.each(medical_record.prescription, function(index, record) {
		//var html_content = '<tr class="row100 body">' + '<td class="cell100 column1">' + record.name + '</td>' + '<td class="cell100 column2">' + record.Dosage + '</td>' + '<td class="cell100 column3">' + record.frequency + '<td class="cell100 column4"><input type="text">' + '</td>'
		var html_content = '<tr class="row100 body">' + '<td class="cell100 column1">' + record.name + '</td>' + '<td class="cell100 column2">' + record.route + '</td>' + '<td class="cell100 column3">' + record.Dosage + '</td>' + '<td class="cell100 column4">' + record.frequency + '</td>' + '<td class="cell100 column5">' + record.days_supply + '</td>' + '<td class="cell100 column6">' + record.script_date + '</td>' + '<td class="cell100 column7">' + record.trans_date + '</td>' + '<td class="cell100 column8">' + record.prescriber + '</td>' + '<td class="cell100 column4"><input type="text" style="    width: 105px">' + '</td>'+'</tr>'
		

		$("#med_prescription").append(html_content);
	})
	$('.column100').on('mouseover', function() {
		var table1 = $(this).parent().parent().parent();
		var table2 = $(this).parent().parent();
		var verTable = $(table1).data('vertable') + "";
		var column = $(this).data('column') + "";

		$(table2).find("." + column).addClass('hov-column-' + verTable);
		$(table1).find(".row100.head ." + column).addClass('hov-column-head-' + verTable);
	});

	$('.column100').on('mouseout', function() {
		var table1 = $(this).parent().parent().parent();
		var table2 = $(this).parent().parent();
		var verTable = $(table1).data('vertable') + "";
		var column = $(this).data('column') + "";

		$(table2).find("." + column).removeClass('hov-column-' + verTable);
		$(table1).find(".row100.head ." + column).removeClass('hov-column-head-' + verTable);
	});
	$("#sendToPhysician").click(function() {
		alert("Sucessfully Sent to Physician")
	});

})(jQuery);

/*
 * $(document).ready( function() { abc();
 * 
 * });
 */