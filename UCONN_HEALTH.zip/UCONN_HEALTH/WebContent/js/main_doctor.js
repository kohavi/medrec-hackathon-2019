/*var medical_record = {
	"patient_id" : "1",
	"prescription" : [ {
		"name" : "med1",
		"Dosage" : "500mg",
		"frequency" : "2",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "50mg",
		"frequency" : "1",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "350mg",
		"frequency" : "1",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "500mg",
		"frequency" : "2",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "50mg",
		"frequency" : "1",
		"comment" : ""
	}, {
		"name" : "med1",
		"Dosage" : "350mg",
		"frequency" : "1",
		"comment" : ""
	} ]
};
 */
(function abc($) {
	"use strict";
	$.each(medical_record.prescription, function(index, record) {
		var html_content = '<tr class="row100 body">' + '<td class="cell100 column1">' + record.name + '</td>' + '<td class="cell100 column2">' + record.route + '</td>' + '<td class="cell100 column3">' + record.Dosage + '</td>' + '<td class="cell100 column4">' + record.frequency + '</td>' + '<td class="cell100 column5">' + record.days_supply + '</td>' + '<td class="cell100 column6">' + record.script_date + '</td>' + '<td class="cell100 column7">' + record.trans_date + '</td>' + '<td class="cell100 column8">' + record.prescriber + '</td>' + '</tr>'
		$("#med_prescription").append(html_content);
	})
	$('.column100').on('mouseover', function() {
		var table1 = $(this).parent().parent().parent();
		var table2 = $(this).parent().parent();
		var verTable = $(table1).data('vertable') + "";
		var column = $(this).data('column') + "";

		$(table2).find("." + column).addClass('hov-column-' + verTable);
		$(table1).find(".row100.head ." + column).addClass('hov-column-head-' + verTable);
	});

	$('.column100').on('mouseout', function() {
		var table1 = $(this).parent().parent().parent();
		var table2 = $(this).parent().parent();
		var verTable = $(table1).data('vertable') + "";
		var column = $(this).data('column') + "";

		$(table2).find("." + column).removeClass('hov-column-' + verTable);
		$(table1).find(".row100.head ." + column).removeClass('hov-column-head-' + verTable);
	});
	$("#savePrescription").click(function() {
		$('#med_prescription tr').each(function() {
			if (typeof ($('.med_name', this).val()) != 'undefined') {
				var obj = {};
				obj.name = $('.med_name', this).val();
				obj.route = $('.route', this).val();
				obj.Dosage = $('.dosage', this).val();
				obj.frequency = $('.frequency', this).val();
				obj.days_supply = $('.days_supply', this).val();
				obj.script_date = $('.script_date', this).val();
				obj.trans_date = $('.trans_date', this).val();
				obj.prescriber = $('.prescriber', this).val();

				medical_record.prescription.push(obj)
			}
		});
		$("#med_prescription").html('');
		$.each(medical_record.prescription, function(index, record) {
			var html_content = '<tr class="row100 body">' + '<td class="cell100 column1">' + record.name + '</td>' + '<td class="cell100 column2">' + record.route + '</td>' + '<td class="cell100 column3">' + record.Dosage + '</td>' + '<td class="cell100 column4">' + record.frequency + '</td>' + '<td class="cell100 column5">' + record.days_supply + '</td>' + '<td class="cell100 column6">' + record.script_date + '</td>' + '<td class="cell100 column7">' + record.trans_date + '</td>' + '<td class="cell100 column8">' + record.prescriber + '</td>' + '</tr>'
			$("#med_prescription").append(html_content);

		})
		alert("Saved succesfully")
		/*
		 * document.getElementById("mainPage").innerHTML = '<object
		 * type="text/html" data="index.html" style="height: 100%; width: 100%" ></object>'; ;
		 */
	});

	$("#insertRecord").click(function() {
		console.log("clicked");
		var html_content = '<tr class="row100 body">' + '<td class="cell100 column1"><input class="med_name" type="text" style="width: 90px;">' + '</td>' + '<td class="cell100 column2"><input class="route" type="text" style="width: 90px;" >' + '</td>' + '<td class="cell100 column3"><input class="dosage" type="text" style="width: 90px;">' + '</td>' + '<td class="cell100 column4"><input class="frequency" type="text" style="width: 90px;">' + '</td>' + '<td class="cell100 column5"><input class="days_supply" type="text" style="width: 90px;">' + '</td>' + '<td class="cell100 column6"><input class="script_date" type="text" style="width: 90px;">' + '</td>' + '<td class="cell100 column7"><input class="trans_date" type="text" style="width: 90px;">' + '</td>' + '<td class="cell100 column8"><input class="prescriber" type="text" style="width: 90px;">' + '</td>' + '</tr>'
		$("#med_prescription").append(html_content);
	});

})(jQuery);

/*
 * $(document).ready( function() { abc();
 * 
 * });
 */